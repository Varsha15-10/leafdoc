# Credits and licence notes

## Pretrained model
`android/app/src/main/assets/leaf_model.tflite` is `myModel.tflite` from
https://github.com/mouathayed/Plant-Disease-Detection (LeafGuard, by Mouath Ayed),
a MobileNetV2 model trained on PlantVillage.

That repository has no LICENSE file, so the author keeps all rights by default.
It is included here for study and a course project, with credit. Before you publish the app
or use it commercially, ask the author for permission or replace it with a model you train
yourself using `training/train_colab.ipynb`.

## Dataset
PlantVillage: Hughes and Salathe, "An open access repository of images on plant health to
enable the development of mobile disease diagnostics", 2015. https://github.com/spMohanty/PlantVillage-Dataset

## Advice text
`training/knowledge_base.py` was written for this project. It is general guidance and not a
substitute for local agricultural advice.
