# LeafDoc: Android leaf disease detector

An Android app that works offline. Take or choose a leaf photo and a TensorFlow Lite model running on the phone finds the disease. The app then shows why it happened, the deficiency check, the fertilizer to add, how to recover and how to prevent it. No server and no online AI service.

```
photo -> 224x224 -> MobileNetV2 (TFLite, 38 classes) -> class name
class name -> assets/knowledge_base.json -> causes, deficiency, fertilizer, treatment, prevention
```

## The model is already included

`android/app/src/main/assets/leaf_model.tflite` is a pretrained MobileNetV2 model taken from the open-source LeafGuard project (see `NOTICE.md`). It was trained on PlantVillage, the same 38 classes this app uses. I tested it on 200 real PlantVillage photos across 5 classes and it got 198 right. Those photos are probably from its own training data, so expect lower accuracy on your own field photos.

You do not need to train anything. Training is optional (see the last section) if your course needs you to train your own model.

## What is in the zip

| Folder | Purpose |
|---|---|
| `android/` | The Android Studio project (Kotlin), model and advice included |
| `training/` | Optional: train your own model on Colab and replace the included one |
| `.github/workflows/build-apk.yml` | Builds the APK in the cloud from GitHub, no Android Studio needed |
| `NOTICE.md` | Credits and licence note for the model and dataset |

## Step 1: build the APK

Option A, Android Studio (on a computer):
1. File > Open, choose the `android` folder, wait for Gradle sync.
2. Plug in your phone with USB debugging on and press Run, or use Build > Build APK(s).

Option B, browser only:
1. Create a GitHub repository and upload this whole project.
2. Open the Actions tab, run "Build APK", then download `LeafDoc-debug-apk` from the finished run.

## Step 2: install on the phone

Copy `app-debug.apk` to the phone, open it and allow "install unknown apps" when asked. Open LeafDoc, tap Take photo or Gallery, then Scan and diagnose.

## Troubleshooting

- "Model file is missing" in the app: `leaf_model.tflite` is not in `android/app/src/main/assets/`.
- Error mentioning "Didn't find op for builtin opcode ... version": raise the `org.tensorflow:tensorflow-lite` version in `android/app/build.gradle.kts`.
- Wrong answers on field photos: PlantVillage photos have plain backgrounds. Photograph one leaf, close up, in daylight, on a plain background.

## Limits for your report

- 14 crops and 38 classes only. The model has no "not a leaf" class, so a photo of something else still gets a confident wrong answer. Only scan single leaves of the supported crops.
- PlantVillage has no nutrient-deficiency classes. The deficiency line is a note per disease. To detect deficiencies directly, train with extra deficiency classes and add matching advice in `training/knowledge_base.py`.
- Fertilizer and treatment lines are general guidance with no doses. Follow product labels and local advice.
- The app warns when confidence is below 60 percent.

## Optional: train your own model

1. Go to colab.research.google.com, upload `training/train_colab.ipynb`, and set Runtime > Change runtime type > GPU.
2. Run the cells in order. When asked, upload this project's zip.
3. At the end it downloads `assets.zip`. Unzip it and copy the `assets` folder into `android/app/src/main/`, replacing the existing one.

Training takes about 20 to 40 minutes and prints your validation accuracy for your report. On a PC: `pip install -r training/requirements.txt`, put PlantVillage colour images in `training/data/`, then run `python train.py` and `python export_android.py` inside `training/`.
