package com.leafdoc.app

import android.content.Context
import android.graphics.Bitmap
import org.json.JSONArray
import org.tensorflow.lite.Interpreter
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.channels.FileChannel

data class Prediction(val className: String, val probability: Float)

/** Runs the TensorFlow Lite leaf model on the phone. No network is used. */
class Classifier(context: Context) : AutoCloseable {

    private val interpreter: Interpreter
    val labels: List<String>

    init {
        val fd = context.assets.openFd(MODEL_FILE)
        val mapped = FileInputStream(fd.fileDescriptor).use { stream ->
            stream.channel.map(FileChannel.MapMode.READ_ONLY, fd.startOffset, fd.declaredLength)
        }
        fd.close()
        interpreter = Interpreter(mapped)

        val json = context.assets.open(LABELS_FILE).bufferedReader().use { it.readText() }
        val array = JSONArray(json)
        labels = List(array.length()) { array.getString(it) }
    }

    /** Returns the [topK] most likely classes, best first. */
    fun classify(source: Bitmap, topK: Int = 3): List<Prediction> {
        val scaled = Bitmap.createScaledBitmap(source, SIZE, SIZE, true)
        val pixels = IntArray(SIZE * SIZE)
        scaled.getPixels(pixels, 0, SIZE, 0, 0, SIZE, SIZE)

        // The model scales pixels itself, so it takes raw 0-255 RGB floats.
        val input = ByteBuffer.allocateDirect(4 * SIZE * SIZE * 3).order(ByteOrder.nativeOrder())
        for (p in pixels) {
            input.putFloat(((p shr 16) and 0xFF).toFloat())
            input.putFloat(((p shr 8) and 0xFF).toFloat())
            input.putFloat((p and 0xFF).toFloat())
        }
        input.rewind()

        val output = Array(1) { FloatArray(labels.size) }
        interpreter.run(input, output)

        return output[0].withIndex()
            .sortedByDescending { it.value }
            .take(topK)
            .map { Prediction(labels[it.index], it.value) }
    }

    override fun close() {
        interpreter.close()
    }

    companion object {
        const val MODEL_FILE = "leaf_model.tflite"
        const val LABELS_FILE = "classes.json"
        const val SIZE = 224
    }
}
