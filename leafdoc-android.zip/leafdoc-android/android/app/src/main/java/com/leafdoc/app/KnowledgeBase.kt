package com.leafdoc.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Advice(
    val plant: String,
    val condition: String,
    val category: String,
    val causes: List<String>,
    val nutrient: String,
    val fertilizer: List<String>,
    val treatment: List<String>,
    val prevention: List<String>,
)

/** Advice for each class the model can predict, loaded from assets/knowledge_base.json. */
class KnowledgeBase(context: Context) {

    private val root: JSONObject =
        JSONObject(context.assets.open("knowledge_base.json").bufferedReader().use { it.readText() })

    fun get(className: String): Advice? {
        val o = root.optJSONObject(className) ?: return null
        return Advice(
            plant = o.optString("plant"),
            condition = o.optString("condition"),
            category = o.optString("category"),
            causes = strings(o.optJSONArray("causes")),
            nutrient = o.optString("nutrient"),
            fertilizer = strings(o.optJSONArray("fertilizer")),
            treatment = strings(o.optJSONArray("treatment")),
            prevention = strings(o.optJSONArray("prevention")),
        )
    }

    private fun strings(array: JSONArray?): List<String> =
        if (array == null) emptyList() else List(array.length()) { array.getString(it) }
}
