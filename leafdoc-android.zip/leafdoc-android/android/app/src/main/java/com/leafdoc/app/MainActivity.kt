package com.leafdoc.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Bundle
import android.util.TypedValue
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.exifinterface.media.ExifInterface
import com.google.android.material.button.MaterialButton
import java.io.File
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var btnCamera: MaterialButton
    private lateinit var btnGallery: MaterialButton
    private lateinit var btnScan: MaterialButton
    private lateinit var preview: ImageView
    private lateinit var progress: ProgressBar
    private lateinit var message: TextView
    private lateinit var resultBox: LinearLayout

    private var classifier: Classifier? = null
    private var knowledge: KnowledgeBase? = null
    private var currentBitmap: Bitmap? = null
    private var cameraUri: Uri? = null
    private val worker = Executors.newSingleThreadExecutor()

    private val takePicture =
        registerForActivityResult(ActivityResultContracts.TakePicture()) { saved ->
            val uri = cameraUri
            if (saved && uri != null) showPhoto(uri)
        }

    private val pickImage =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) showPhoto(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnCamera = findViewById(R.id.btnCamera)
        btnGallery = findViewById(R.id.btnGallery)
        btnScan = findViewById(R.id.btnScan)
        preview = findViewById(R.id.preview)
        progress = findViewById(R.id.progress)
        message = findViewById(R.id.message)
        resultBox = findViewById(R.id.result)

        savedInstanceState?.getString("cameraUri")?.let { cameraUri = Uri.parse(it) }

        try {
            classifier = Classifier(this)
            knowledge = KnowledgeBase(this)
        } catch (e: Exception) {
            showMessage(
                "The model file is missing from the app. Train the model and copy leaf_model.tflite " +
                    "into app/src/main/assets, then rebuild. (${e.message})"
            )
        }

        btnCamera.setOnClickListener { launchCamera() }
        btnGallery.setOnClickListener { pickImage.launch("image/*") }
        btnScan.setOnClickListener { scan() }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        cameraUri?.let { outState.putString("cameraUri", it.toString()) }
    }

    override fun onDestroy() {
        super.onDestroy()
        worker.shutdown()
        classifier?.close()
    }

    private fun launchCamera() {
        val dir = File(cacheDir, "images").apply { mkdirs() }
        val file = File(dir, "leaf_${System.currentTimeMillis()}.jpg")
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        cameraUri = uri
        try {
            takePicture.launch(uri)
        } catch (e: Exception) {
            showMessage("No camera app found. Use Gallery instead.")
        }
    }

    private fun showPhoto(uri: Uri) {
        val bitmap = decode(uri)
        if (bitmap == null) {
            showMessage("That photo could not be opened. Try another one.")
            return
        }
        currentBitmap = bitmap
        preview.setImageBitmap(bitmap)
        preview.visibility = View.VISIBLE
        resultBox.removeAllViews()
        message.visibility = View.GONE
        btnScan.isEnabled = classifier != null
    }

    private fun scan() {
        val bitmap = currentBitmap ?: return
        val model = classifier ?: return
        btnScan.isEnabled = false
        progress.visibility = View.VISIBLE
        message.visibility = View.GONE
        resultBox.removeAllViews()

        worker.execute {
            val outcome = runCatching { model.classify(bitmap) }
            runOnUiThread {
                progress.visibility = View.GONE
                btnScan.isEnabled = true
                outcome
                    .onSuccess { showResult(it) }
                    .onFailure { showMessage("Scan failed: ${it.message}") }
            }
        }
    }

    private fun showResult(top: List<Prediction>) {
        val best = top.first()
        val advice = knowledge?.get(best.className)
        resultBox.removeAllViews()

        if (advice != null) {
            addText(advice.plant.uppercase(), 12f, bold = false, alpha = 0.6f)
            addText(advice.condition, 24f, bold = true)
            addText(advice.category, 14f, bold = false, alpha = 0.7f)
        } else {
            addText(prettyLabel(best.className), 24f, bold = true)
        }

        addText("Model confidence ${(best.probability * 100).toInt()}%", 13f, bold = false, alpha = 0.7f)
        resultBox.addView(ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = (best.probability * 100).toInt()
        })

        if (best.probability < LOW_CONFIDENCE) {
            addText(
                "The model is not sure. Retake the photo: one leaf, filling the frame, in daylight, " +
                    "in focus, plain background.",
                14f, bold = true,
            )
        }

        if (advice != null) {
            addSection("Why it happened", advice.causes)
            addSection("Deficiency check", listOf(advice.nutrient), bullets = false)
            addSection("Fertilizer to add", advice.fertilizer)
            addSection("How to recover", advice.treatment)
            addSection("Prevent it next time", advice.prevention)
        }

        addSection(
            "Other possibilities",
            top.map { "${prettyLabel(it.className)}  ${(it.probability * 100).toInt()}%" },
        )
    }

    private fun addSection(title: String, lines: List<String>, bullets: Boolean = true) {
        if (lines.isEmpty()) return
        addText(title, 17f, bold = true, topMargin = 20)
        for (line in lines) addText(if (bullets) "•  $line" else line, 15f, bold = false, topMargin = 4)
    }

    private fun addText(
        text: String,
        sizeSp: Float,
        bold: Boolean,
        alpha: Float = 1f,
        topMargin: Int = 6,
    ) {
        val tv = TextView(this).apply {
            this.text = text
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
            this.alpha = alpha
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT,
        )
        lp.topMargin = (topMargin * resources.displayMetrics.density).toInt()
        resultBox.addView(tv, lp)
    }

    private fun showMessage(text: String) {
        message.text = text
        message.visibility = View.VISIBLE
    }

    private fun prettyLabel(className: String): String {
        val plant = className.substringBefore("___").replace('_', ' ').trim()
        val condition = className.substringAfter("___", "").replace('_', ' ').trim()
        return if (condition.isEmpty()) plant else "$plant: $condition"
    }

    /** Opens the photo at a sensible size and turns it upright using its EXIF orientation. */
    private fun decode(uri: Uri): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > MAX_SIDE || bounds.outHeight / sample > MAX_SIDE) sample *= 2

            val options = BitmapFactory.Options().apply { inSampleSize = sample }
            val bitmap = contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, options)
            } ?: return null

            val orientation = contentResolver.openInputStream(uri)?.use {
                ExifInterface(it).getAttributeInt(
                    ExifInterface.TAG_ORIENTATION,
                    ExifInterface.ORIENTATION_NORMAL,
                )
            } ?: ExifInterface.ORIENTATION_NORMAL

            val degrees = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (degrees == 0f) {
                bitmap
            } else {
                val matrix = Matrix().apply { postRotate(degrees) }
                Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
            }
        } catch (e: Exception) {
            null
        }
    }

    companion object {
        private const val LOW_CONFIDENCE = 0.60f
        private const val MAX_SIDE = 2048
    }
}
