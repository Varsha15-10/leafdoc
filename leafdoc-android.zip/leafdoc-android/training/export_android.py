"""Copy the model, class list and advice into the Android project's assets folder.

Run after train.py:   python export_android.py
Without a trained model it still writes classes.json and knowledge_base.json
(using the standard 38 PlantVillage class names) so only the .tflite is missing.
"""
import json
import shutil
from pathlib import Path

from knowledge_base import PLANTVILLAGE_CLASSES, lookup

ROOT = Path(__file__).parent
ASSETS = ROOT.parent / "android" / "app" / "src" / "main" / "assets"
FIELDS = ("plant", "condition", "category", "causes", "nutrient", "fertilizer", "treatment", "prevention")


def main():
    model_dir = ROOT / "model"
    classes_file = model_dir / "classes.json"
    classes = json.loads(classes_file.read_text()) if classes_file.exists() else sorted(PLANTVILLAGE_CLASSES)

    ASSETS.mkdir(parents=True, exist_ok=True)
    (ASSETS / "classes.json").write_text(json.dumps(classes, indent=2))

    kb = {name: {k: lookup(name)[k] for k in FIELDS} for name in classes}
    (ASSETS / "knowledge_base.json").write_text(json.dumps(kb, indent=2, ensure_ascii=False))

    tflite = model_dir / "leaf_model.tflite"
    if tflite.exists():
        shutil.copy(tflite, ASSETS / "leaf_model.tflite")
        print("Copied leaf_model.tflite")
    else:
        print("leaf_model.tflite not found. Train first (train.py), then run this again.")
    print(f"Wrote {len(classes)} classes and advice to {ASSETS}")


if __name__ == "__main__":
    main()
