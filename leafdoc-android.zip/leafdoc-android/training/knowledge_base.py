"""Knowledge base: what each predicted class means and what to do about it.

The classifier only outputs a class name. This file turns that name into the
advice shown to the user: why it happened, any nutrient link, which fertilizer
to add, how to treat it and how to prevent it.

Chemical names are common label options only. Dose and legality depend on the
product label and local rules, so none are given here.
"""
import re


def normalize(text):
    """'Tomato___Early_blight' -> 'tomatoearlyblight'"""
    return re.sub(r"[^a-z0-9]", "", text.lower())


KB = []


def add(match, plant, condition, category, causes, nutrient, fertilizer, treatment, prevention):
    KB.append(
        dict(
            match=match,
            plant=plant,
            condition=condition,
            category=category,
            causes=causes,
            nutrient=nutrient,
            fertilizer=fertilizer,
            treatment=treatment,
            prevention=prevention,
        )
    )


# ---------------------------------------------------------------- APPLE
add(["apple", "applescab"], "Apple", "Apple scab", "Fungal (Venturia inaequalis)",
    ["The fungus survives the winter in fallen leaves and releases spores in cool, wet spring weather.",
     "Leaves that stay wet for many hours let spores infect."],
    "Not a deficiency. Too much nitrogen gives soft, susceptible growth.",
    ["Balanced NPK, nitrogen split into small doses", "Compost or farmyard manure to keep the tree vigorous"],
    ["Rake and destroy fallen leaves", "Prune to open the canopy for airflow",
     "Protectant fungicide such as sulphur, captan or mancozeb from bud break, as per label"],
    ["Plant scab-resistant varieties", "Clear leaf litter every autumn"])
add(["apple", "blackrot"], "Apple", "Black rot", "Fungal (Botryosphaeria obtusa)",
    ["The fungus lives in dead wood, cankers and mummified fruit.",
     "Warm, wet weather and stressed trees favour infection."],
    "Not a deficiency. Weak, drought-stressed trees get it more.",
    ["Balanced NPK based on a soil test", "Mulch and irrigate in dry spells to avoid stress"],
    ["Cut out cankers and dead branches and burn them", "Remove mummified fruit",
     "Fungicide as per label during bloom and early fruit set"],
    ["Prune in dry weather", "Keep trees well watered and fed"])
add(["apple", "cedarapplerust"], "Apple", "Cedar apple rust", "Fungal (Gymnosporangium)",
    ["The fungus needs both juniper or cedar trees and apple trees to complete its life cycle.",
     "Spring rain releases spores from galls on juniper onto apple leaves."],
    "Not a deficiency.",
    ["Balanced NPK to keep the tree healthy"],
    ["Remove galls from nearby junipers if possible", "Protectant fungicide from pink bud to petal fall, as per label"],
    ["Plant resistant apple varieties", "Avoid planting apples close to juniper"])
add(["cherry", "powderymildew"], "Cherry", "Powdery mildew", "Fungal (Podosphaera)",
    ["Warm days, cool humid nights and crowded canopies.",
     "Young leaves and shoots are infected first."],
    "Not a deficiency. Heavy nitrogen feeding produces tender growth that mildew loves.",
    ["Balanced NPK, avoid excess nitrogen", "Potassium helps tissue toughness"],
    ["Prune for airflow", "Sulphur or potassium bicarbonate spray, or a fungicide as per label"],
    ["Choose resistant varieties", "Do not overcrowd trees"])
# ---------------------------------------------------------------- CORN
add(["corn", "cercospora"], "Corn (maize)", "Gray leaf spot", "Fungal (Cercospora zeae-maydis)",
    ["The fungus survives on corn residue left in the field.",
     "Warm, humid weather and corn grown after corn make it worse."],
    "Not a deficiency. Low potassium or nitrogen can make plants more vulnerable.",
    ["Balanced N, P and K by soil test", "Do not let the crop run short of potash"],
    ["Fungicide as per label if lesions climb toward the ear leaf", "Plough in residue after harvest"],
    ["Rotate with a non-cereal crop", "Grow resistant hybrids"])
add(["corn", "commonrust"], "Corn (maize)", "Common rust", "Fungal (Puccinia sorghi)",
    ["Wind carries rust spores from far away.",
     "Cool, moist weather with heavy dew favours it."],
    "Not a deficiency.",
    ["Balanced NPK to keep the crop vigorous"],
    ["Fungicide as per label if pustules are heavy before tasselling"],
    ["Plant resistant hybrids", "Sow early so the crop matures before peak rust weather"])
add(["corn", "northernleafblight"], "Corn (maize)", "Northern leaf blight", "Fungal (Exserohilum turcicum)",
    ["The fungus overwinters on crop residue.",
     "Moderate temperatures with long periods of dew and leaf wetness."],
    "Not a deficiency. Nutrient-stressed plants suffer more.",
    ["Balanced N, P and K by soil test"],
    ["Fungicide as per label at early signs", "Bury infected residue after harvest"],
    ["Rotate crops", "Use resistant hybrids"])
# ---------------------------------------------------------------- GRAPE
add(["grape", "blackrot"], "Grape", "Black rot", "Fungal (Guignardia bidwellii)",
    ["Spores come from mummified berries and infected canes left on the vine or ground.",
     "Warm, wet spells during early growth."],
    "Not a deficiency.",
    ["Balanced NPK, avoid excess nitrogen that creates dense canopy"],
    ["Remove mummified berries and infected shoots", "Fungicide such as mancozeb or myclobutanil from early shoot growth, as per label"],
    ["Train vines for open canopy and airflow", "Clean up mummies each winter"])
add(["grape", "esca"], "Grape", "Esca (black measles)", "Fungal wood disease (several fungi)",
    ["Fungi enter through pruning wounds and live inside the wood.",
     "Water stress and old, heavily pruned vines show symptoms more."],
    "Not a deficiency. Do not confuse with magnesium deficiency stripes.",
    ["Balanced feeding and steady irrigation to reduce stress"],
    ["There is no cure. Cut out dead wood and burn it", "Protect large pruning cuts with a wound sealant",
     "Remove badly affected vines"],
    ["Prune in dry weather", "Disinfect pruning tools between vines"])
add(["grape", "leafblight"], "Grape", "Leaf blight (Isariopsis leaf spot)", "Fungal (Pseudocercospora vitis)",
    ["The fungus overwinters on fallen leaves.",
     "Humid, warm weather late in the season."],
    "Not a deficiency. Weak vines suffer more.",
    ["Balanced NPK, adequate potassium"],
    ["Copper-based or other protectant fungicide as per label", "Remove and burn fallen leaves"],
    ["Keep the canopy open", "Avoid overhead irrigation"])
# ---------------------------------------------------------------- ORANGE
add(["orange", "haunglongbing"], "Orange (citrus)", "Citrus greening (Huanglongbing)", "Bacterial (Candidatus Liberibacter)",
    ["The bacterium spreads through plant tissue and is carried by the Asian citrus psyllid insect.",
     "Infected budwood and nursery plants spread it over long distances."],
    "Looks like zinc, manganese or iron deficiency (blotchy mottling), but the cause is the bacterium.",
    ["Foliar zinc, manganese and magnesium mix to support the tree", "Balanced NPK. This helps the tree cope but does not cure"],
    ["There is no cure. Remove and destroy infected trees", "Control psyllids with an insecticide as per label and local advice",
     "Report to your agriculture department"],
    ["Plant only certified disease-free saplings", "Scout for psyllids regularly"])
# ---------------------------------------------------------------- PEACH / PEPPER
add(["peach", "bacterialspot"], "Peach", "Bacterial spot", "Bacterial (Xanthomonas arboricola)",
    ["Bacteria survive in twig lesions and spread by wind-driven rain.",
     "Warm, wet weather and over-fertilised trees."],
    "Not a deficiency. Excess nitrogen makes it worse.",
    ["Balanced NPK, avoid heavy nitrogen"],
    ["Copper spray as per label in the dormant season and early growth", "Prune out infected twigs"],
    ["Plant tolerant varieties", "Windbreaks and good drainage"])
add(["pepper", "bacterialspot"], "Bell pepper", "Bacterial spot", "Bacterial (Xanthomonas)",
    ["Infected seed and crop residue carry the bacteria.",
     "Rain splash, overhead irrigation and handling wet plants spread it."],
    "Not a deficiency. Calcium shortage causes other problems and can be confused with the spots.",
    ["Balanced NPK", "Calcium source such as gypsum if soil test shows low calcium"],
    ["Copper-based spray as per label", "Remove badly infected plants", "Do not work in the field when leaves are wet"],
    ["Use clean, treated seed", "Rotate with non-solanaceous crops for 2 to 3 years", "Drip irrigation instead of sprinklers"])
# ---------------------------------------------------------------- POTATO
add(["potato", "earlyblight"], "Potato", "Early blight", "Fungal (Alternaria solani)",
    ["Spores survive on crop debris and in soil.",
     "Older leaves and plants short of nutrients or water are hit first."],
    "Low nitrogen, phosphorus or potassium weakens plants and lets it spread faster.",
    ["Balanced NPK by soil test, with enough nitrogen and potash", "Farmyard manure or compost before planting"],
    ["Remove infected lower leaves", "Fungicide such as mancozeb or chlorothalonil as per label"],
    ["Rotate crops for 3 years", "Plant certified seed tubers", "Keep plants well fed and irrigated"])
add(["potato", "lateblight"], "Potato", "Late blight", "Oomycete (Phytophthora infestans)",
    ["Spores spread by wind and rain from infected plants, volunteer potatoes and seed tubers.",
     "Cool, wet, foggy weather lets it destroy a crop within days."],
    "Not a deficiency. Too much nitrogen gives lush growth that is more at risk.",
    ["Balanced NPK, avoid excess nitrogen", "Potash helps tuber quality"],
    ["Act at once: remove and destroy infected plants", "Protectant plus systemic fungicide as per label and local advice",
     "Stop irrigation and dig tubers only after the haulms are dead"],
    ["Use certified seed", "Hill soil well over tubers", "Destroy cull piles and volunteers"])
# ---------------------------------------------------------------- SQUASH / STRAWBERRY
add(["squash", "powderymildew"], "Squash", "Powdery mildew", "Fungal (Podosphaera xanthii)",
    ["Warm days and humid nights, crowded plants and shade.",
     "Spores blow in on the wind and do not need wet leaves."],
    "Not a deficiency. Excess nitrogen produces tender, susceptible leaves.",
    ["Balanced NPK, avoid heavy nitrogen"],
    ["Sulphur, neem oil or potassium bicarbonate spray, or a fungicide as per label", "Remove badly affected leaves"],
    ["Give plants space", "Choose mildew-resistant varieties", "Water at the base"])
add(["strawberry", "leafscorch"], "Strawberry", "Leaf scorch", "Fungal (Diplocarpon earlianum)",
    ["Spores splash from old infected leaves onto new ones.",
     "Wet weather and dense plantings."],
    "Not a deficiency.",
    ["Balanced NPK, avoid excess nitrogen"],
    ["Remove infected old leaves after harvest", "Fungicide as per label"],
    ["Use resistant varieties", "Drip irrigation, wider spacing", "Renovate beds after harvest"])
# ---------------------------------------------------------------- TOMATO
add(["tomato", "bacterialspot"], "Tomato", "Bacterial spot", "Bacterial (Xanthomonas)",
    ["Infected seed, seedlings and plant debris carry the bacteria.",
     "Splashing rain, overhead watering and handling wet plants."],
    "Not a deficiency.",
    ["Balanced NPK", "Calcium if soil is low, to keep tissue strong"],
    ["Copper-based spray as per label", "Remove badly infected plants"],
    ["Clean or treated seed", "Rotate crops", "Drip irrigation, no work in wet fields"])
add(["tomato", "earlyblight"], "Tomato", "Early blight", "Fungal (Alternaria solani)",
    ["Spores overwinter in soil and plant debris and splash up onto lower leaves.",
     "Warm, humid weather and plants weakened by uneven feeding."],
    "Low nitrogen or potassium stress makes it spread faster. Scorched leaf edges can mean low potassium.",
    ["Balanced NPK, with potash by soil test", "Compost or manure; split nitrogen doses through the season"],
    ["Remove lower infected leaves", "Fungicide such as mancozeb or chlorothalonil as per label", "Mulch to stop soil splash"],
    ["Rotate away from tomato, potato and brinjal for 2 to 3 seasons", "Stake and space plants", "Water at the base in the morning"])
add(["tomato", "lateblight"], "Tomato", "Late blight", "Oomycete (Phytophthora infestans)",
    ["Spores spread quickly by wind and rain from infected plants.",
     "Cool nights, high humidity and long leaf wetness."],
    "Not a deficiency. Excess nitrogen increases risk.",
    ["Balanced NPK, avoid excess nitrogen"],
    ["Remove and destroy infected plants quickly", "Protectant plus systemic fungicide as per label and local advice"],
    ["Plant tolerant varieties", "Improve airflow, avoid overhead irrigation", "Never compost blighted plants"])
add(["tomato", "leafmold"], "Tomato", "Leaf mold", "Fungal (Passalora fulva)",
    ["Humidity above about 85 percent, common in greenhouses and dense crops.",
     "Poor airflow and leaves staying wet."],
    "Not a deficiency.",
    ["Balanced NPK, avoid excess nitrogen"],
    ["Ventilate and lower humidity", "Remove infected lower leaves", "Fungicide such as chlorothalonil as per label"],
    ["Use resistant varieties", "Wider spacing and pruning", "Water early in the day"])
add(["tomato", "septoria"], "Tomato", "Septoria leaf spot", "Fungal (Septoria lycopersici)",
    ["Spores survive on debris and splash up from the soil.",
     "Warm, wet weather and long leaf wetness."],
    "Not a deficiency. Weak, underfed plants suffer more.",
    ["Balanced NPK based on soil test"],
    ["Remove infected lower leaves", "Fungicide such as chlorothalonil or copper as per label"],
    ["Rotate for 2 to 3 years", "Mulch and stake plants", "Clear debris after harvest"])
add(["tomato", "spidermite"], "Tomato", "Spider mites (two-spotted)", "Pest (Tetranychus urticae)",
    ["Mites multiply fast in hot, dry, dusty weather.",
     "Heavy nitrogen feeding and water-stressed plants favour them."],
    "Not a deficiency. The speckled, bronzed leaves can look like nutrient stress.",
    ["Do not over-apply nitrogen", "Keep plants evenly watered; balanced NPK"],
    ["Strong water spray under leaves", "Neem oil or insecticidal soap, or a miticide as per label", "Remove heavily infested leaves"],
    ["Reduce dust, keep plants watered", "Encourage natural predators", "Check leaf undersides weekly"])
add(["tomato", "targetspot"], "Tomato", "Target spot", "Fungal (Corynespora cassiicola)",
    ["Warm, humid weather with long leaf wetness.",
     "Spores survive on crop debris."],
    "Not a deficiency. Poorly fed plants suffer more.",
    ["Balanced NPK based on soil test"],
    ["Remove infected leaves", "Fungicide as per label", "Improve airflow by pruning and staking"],
    ["Rotate crops", "Clear residue after harvest", "Avoid overhead watering"])
add(["tomato", "yellowleafcurl"], "Tomato", "Yellow leaf curl virus", "Viral (begomovirus, spread by whitefly)",
    ["Whiteflies carry the virus from infected plants to healthy ones.",
     "Warm weather and weeds nearby keep whitefly numbers high."],
    "Yellowing and curling resemble a deficiency, but fertilizer will not fix a virus.",
    ["Balanced NPK to help surviving plants; it does not cure"],
    ["There is no cure. Remove and destroy infected plants", "Control whiteflies with yellow sticky traps, neem oil or insecticide as per label"],
    ["Plant resistant varieties", "Use insect-proof nets in the nursery", "Remove weeds, reflective mulch"])
add(["tomato", "mosaic"], "Tomato", "Tomato mosaic virus", "Viral (ToMV)",
    ["The virus is very stable and spreads on hands, tools and infected seed.",
     "Tobacco products and infected plant debris can carry it."],
    "Mottled leaves can look like nutrient deficiency, but fertilizer will not fix a virus.",
    ["Balanced NPK to help surviving plants; it does not cure"],
    ["There is no cure. Remove and destroy infected plants", "Wash hands and disinfect tools"],
    ["Plant resistant varieties and clean seed", "Do not handle tobacco before touching plants", "Rotate crops"])


# ---------------------------------------------------------------- HEALTHY
def healthy(plant, fertilizer):
    add([normalize(plant), "healthy"], plant, "Healthy leaf", "No disease found",
        ["The leaf shows no sign of disease in this photo."],
        "No clear deficiency visible. Check older and newer leaves too.",
        fertilizer,
        ["No treatment needed"],
        ["Water at the base", "Scout weekly for spots, curling or insects", "Feed by soil test"])


healthy("Apple", ["Balanced NPK in spring, compost each year"])
healthy("Blueberry", ["Acid-forming fertilizer such as ammonium sulphate", "Keep soil pH around 4.5 to 5.5"])
healthy("Cherry", ["Balanced NPK in spring", "Compost mulch"])
healthy("Corn", ["Split nitrogen: at sowing and again at knee height", "Phosphorus at sowing, potash by soil test"])
healthy("Grape", ["Balanced NPK, potash at fruit set", "Compost in winter"])
healthy("Peach", ["Balanced NPK in early spring", "Compost mulch"])
healthy("Pepper", ["Balanced NPK, extra potash at flowering", "Calcium source if soil is low"])
healthy("Potato", ["Basal NPK at planting, extra potash during tuber bulking", "Farmyard manure before planting"])
healthy("Raspberry", ["Balanced NPK in early spring", "Compost mulch"])
healthy("Soybean", ["Seed inoculation with Rhizobium", "Phosphorus and potash by soil test, little nitrogen"])
healthy("Strawberry", ["Balanced NPK after renovation", "Potash at flowering"])
healthy("Tomato", ["Balanced NPK, shift to higher potash at flowering", "Calcium source to prevent blossom end rot"])

GENERIC = dict(
    plant="Unknown",
    condition="No advice on file for this class",
    category="Unknown",
    causes=["The classifier recognised this class but the knowledge base has no entry for it."],
    nutrient="Not available.",
    fertilizer=["Test the soil and feed according to the result"],
    treatment=["Consult a local agriculture officer"],
    prevention=["Scout regularly and keep records"],
)


def lookup(class_name):
    """Return the advice entry whose match words are all inside the class name."""
    key = normalize(class_name)
    best = None
    for entry in KB:
        if all(token in key for token in entry["match"]):
            if best is None or len(entry["match"]) > len(best["match"]):
                best = entry
    return best or GENERIC


PLANTVILLAGE_CLASSES = [
    "Apple___Apple_scab", "Apple___Black_rot", "Apple___Cedar_apple_rust", "Apple___healthy",
    "Blueberry___healthy", "Cherry_(including_sour)___Powdery_mildew", "Cherry_(including_sour)___healthy",
    "Corn_(maize)___Cercospora_leaf_spot Gray_leaf_spot", "Corn_(maize)___Common_rust_",
    "Corn_(maize)___Northern_Leaf_Blight", "Corn_(maize)___healthy",
    "Grape___Black_rot", "Grape___Esca_(Black_Measles)", "Grape___Leaf_blight_(Isariopsis_Leaf_Spot)", "Grape___healthy",
    "Orange___Haunglongbing_(Citrus_greening)", "Peach___Bacterial_spot", "Peach___healthy",
    "Pepper,_bell___Bacterial_spot", "Pepper,_bell___healthy",
    "Potato___Early_blight", "Potato___Late_blight", "Potato___healthy",
    "Raspberry___healthy", "Soybean___healthy", "Squash___Powdery_mildew",
    "Strawberry___Leaf_scorch", "Strawberry___healthy",
    "Tomato___Bacterial_spot", "Tomato___Early_blight", "Tomato___Late_blight", "Tomato___Leaf_Mold",
    "Tomato___Septoria_leaf_spot", "Tomato___Spider_mites Two-spotted_spider_mite", "Tomato___Target_Spot",
    "Tomato___Tomato_Yellow_Leaf_Curl_Virus", "Tomato___Tomato_mosaic_virus", "Tomato___healthy",
]

if __name__ == "__main__":
    missing = [c for c in PLANTVILLAGE_CLASSES if lookup(c) is GENERIC]
    print(f"{len(KB)} entries, {len(PLANTVILLAGE_CLASSES)} classes, missing: {missing or 'none'}")
