"""Train the leaf disease classifier and convert it for the Android app.

Dataset layout (PlantVillage colour images), one folder per class:

    data/Apple___Apple_scab/*.jpg
    data/Tomato___Early_blight/*.jpg
    ...

Usage:
    python train.py --data data --epochs 5 --fine-tune-epochs 3

Outputs in model/:
    leaf_model.keras    trained network
    leaf_model.tflite   the same network for the phone (input: 224x224x3 floats 0-255)
    classes.json        class names in the order the network outputs them
"""
import argparse
import json
from pathlib import Path

import tensorflow as tf
from tensorflow.keras import layers, models

IMG_SIZE = (224, 224)


def build_model(num_classes, weights="imagenet"):
    augment = models.Sequential(
        [
            layers.RandomFlip("horizontal_and_vertical"),
            layers.RandomRotation(0.15),
            layers.RandomZoom(0.15),
            layers.RandomContrast(0.15),
        ],
        name="augmentation",
    )
    base = tf.keras.applications.MobileNetV2(
        input_shape=IMG_SIZE + (3,), include_top=False, weights=weights
    )
    base.trainable = False

    inputs = layers.Input(shape=IMG_SIZE + (3,))
    x = augment(inputs)  # only active while training
    x = tf.keras.applications.mobilenet_v2.preprocess_input(x)  # 0-255 -> [-1, 1], inside the model
    x = base(x, training=False)
    x = layers.GlobalAveragePooling2D()(x)
    x = layers.Dropout(0.25)(x)
    outputs = layers.Dense(num_classes, activation="softmax")(x)
    return models.Model(inputs, outputs), base


def export_tflite(model, path):
    converter = tf.lite.TFLiteConverter.from_keras_model(model)
    Path(path).write_bytes(converter.convert())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data")
    ap.add_argument("--epochs", type=int, default=5, help="epochs with the base frozen")
    ap.add_argument("--fine-tune-epochs", type=int, default=3, help="epochs with top layers unfrozen")
    ap.add_argument("--batch", type=int, default=32)
    ap.add_argument("--out", default="model")
    args = ap.parse_args()

    common = dict(
        directory=args.data,
        validation_split=0.2,
        seed=42,
        image_size=IMG_SIZE,
        batch_size=args.batch,
        label_mode="categorical",
    )
    train_ds = tf.keras.utils.image_dataset_from_directory(subset="training", **common)
    val_ds = tf.keras.utils.image_dataset_from_directory(subset="validation", **common)
    class_names = train_ds.class_names
    print(f"{len(class_names)} classes found")

    train_ds = train_ds.shuffle(1000).prefetch(tf.data.AUTOTUNE)
    val_ds = val_ds.prefetch(tf.data.AUTOTUNE)

    model, base = build_model(len(class_names))
    model.compile(optimizer=tf.keras.optimizers.Adam(1e-3), loss="categorical_crossentropy", metrics=["accuracy"])
    stop = [tf.keras.callbacks.EarlyStopping(patience=2, restore_best_weights=True)]

    print("Stage 1: train the new classifier head")
    model.fit(train_ds, validation_data=val_ds, epochs=args.epochs, callbacks=stop)

    print("Stage 2: fine-tune the top of MobileNetV2")
    base.trainable = True
    for layer in base.layers[:-40]:
        layer.trainable = False
    model.compile(optimizer=tf.keras.optimizers.Adam(1e-5), loss="categorical_crossentropy", metrics=["accuracy"])
    model.fit(train_ds, validation_data=val_ds, epochs=args.fine_tune_epochs, callbacks=stop)

    _, acc = model.evaluate(val_ds)
    print(f"Validation accuracy: {acc:.4f}")

    out = Path(args.out)
    out.mkdir(exist_ok=True)
    model.save(out / "leaf_model.keras")
    (out / "classes.json").write_text(json.dumps(class_names, indent=2))
    export_tflite(model, out / "leaf_model.tflite")
    print(f"Saved model, classes.json and leaf_model.tflite in {out}/")
    print("Next: python export_android.py")


if __name__ == "__main__":
    main()
